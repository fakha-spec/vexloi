import { Container } from '../components/layout/Container';
import { PageSection } from '../components/layout/PageSection';
import { SectionLabel } from '../components/ui/SectionLabel';
import { AnimatedReveal } from '../components/ui/AnimatedReveal';

const CheckIcon = () => (
  <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="var(--accent)" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true" style={{ flexShrink: 0, marginTop: '2px' }}>
    <polyline points="20 6 9 17 4 12" />
  </svg>
);

const features = [
  'Understands context, not just keywords',
  'Guides you toward your own answers',
  'Remembers nothing unless you choose',
];

export const SolutionSection = () => (
  <PageSection bg="base">
    <Container>
      <div style={{ textAlign: 'center' }}>
        <AnimatedReveal><SectionLabel text="The solution" /></AnimatedReveal>
        <AnimatedReveal delay={100}>
          <h2 style={{
            fontFamily: 'var(--font-display)',
            fontSize: 'clamp(34px, 4.5vw, 56px)',
            color: 'var(--text-primary)',
            letterSpacing: '-0.03em',
            lineHeight: 1.10,
            maxWidth: '600px',
            margin: '0 auto var(--space-16)',
            fontWeight: 300,
          }}>
            Thinking, <em style={{ fontStyle: 'italic' }}>made clearer.</em>
          </h2>
        </AnimatedReveal>
      </div>

      <AnimatedReveal delay={200}>
        <div
          style={{
            maxWidth: '900px',
            margin: '0 auto',
            background: 'linear-gradient(145deg, rgba(123,110,246,0.12) 0%, transparent 55%)',
            border: '1px solid var(--border-accent)',
            borderRadius: 'var(--radius-xl)',
            padding: 'clamp(24px, 5vw, 48px)',
            boxShadow: 'var(--shadow-accent)',
          }}
        >
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(300px, 1fr))', gap: '48px' }}>
            {/* Text column */}
            <div style={{ alignSelf: 'center' }}>
              <SectionLabel text="How Vexlo works" />
              <h3 style={{
                fontFamily: 'var(--font-display)',
                fontSize: '28px',
                color: 'var(--text-primary)',
                letterSpacing: '-0.025em',
                lineHeight: 1.20,
                marginBottom: 'var(--space-4)',
                fontWeight: 300,
              }}>
                A conversation that goes somewhere.
              </h3>
              <p style={{ fontFamily: 'var(--font-body)', fontSize: 'var(--text-base)', fontWeight: 300, color: 'var(--text-secondary)', lineHeight: 1.7, marginBottom: 'var(--space-6)' }}>
                Vexlo doesn't just listen. It asks the right questions at the right moment — helping you move from mental fog to a clear next step. No advice. No diagnosis. Just guided clarity.
              </p>
              {features.map((f, i) => (
                <div key={i} style={{ display: 'flex', gap: '10px', alignItems: 'flex-start', marginBottom: 'var(--space-3)' }}>
                  <CheckIcon />
                  <span style={{ fontFamily: 'var(--font-body)', fontSize: '14px', fontWeight: 300, color: 'var(--text-secondary)' }}>{f}</span>
                </div>
              ))}
            </div>

            {/* Chat mockup */}
            <div style={{ alignSelf: 'center' }}>
              <div style={{ background: 'var(--bg-void)', border: '1px solid var(--border-subtle)', borderRadius: '12px', padding: 'var(--space-5)', fontFamily: 'var(--font-body)' }}>
                {/* Header */}
                <div style={{ display: 'flex', alignItems: 'center', gap: '8px', marginBottom: 'var(--space-4)', paddingBottom: 'var(--space-3)', borderBottom: '1px solid var(--border-hairline)' }}>
                  <div style={{ width: '8px', height: '8px', background: 'var(--accent)', borderRadius: '50%' }} />
                  <span style={{ fontSize: 'var(--text-sm)', fontWeight: 600, color: 'var(--text-primary)' }}>Vexlo</span>
                  <span style={{ fontSize: 'var(--text-xs)', color: 'var(--text-muted)', marginLeft: 'auto' }}>• Private session</span>
                </div>

                {/* Bubble A - AI */}
                <div style={{ display: 'flex', gap: '8px', alignItems: 'flex-start', marginBottom: '10px' }}>
                  <div style={{ width: '24px', height: '24px', borderRadius: '50%', background: 'var(--accent-muted)', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 'var(--text-xs)', color: 'var(--text-accent)', flexShrink: 0 }}>V</div>
                  <div style={{ background: 'var(--accent-muted)', border: '1px solid rgba(123,110,246,0.2)', borderRadius: '3px 10px 10px 10px', padding: '10px 13px', fontSize: 'var(--text-sm)', color: '#C4B5FD', lineHeight: 1.55, maxWidth: '88%' }}>
                    What's been taking up the most mental space for you lately?
                  </div>
                </div>

                {/* Bubble B - User */}
                <div style={{ display: 'flex', justifyContent: 'flex-end', marginBottom: '10px' }}>
                  <div style={{ background: 'rgba(255,255,255,0.07)', border: '1px solid rgba(255,255,255,0.09)', borderRadius: '10px 3px 10px 10px', padding: '10px 13px', fontSize: 'var(--text-sm)', color: 'var(--text-secondary)', lineHeight: 1.55, maxWidth: '82%' }}>
                    I keep going back and forth on this career decision. I know what I want but I can't actually commit.
                  </div>
                </div>

                {/* Bubble C - AI */}
                <div style={{ display: 'flex', gap: '8px', alignItems: 'flex-start', marginBottom: '10px' }}>
                  <div style={{ width: '24px', height: '24px', borderRadius: '50%', background: 'var(--accent-muted)', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 'var(--text-xs)', color: 'var(--text-accent)', flexShrink: 0 }}>V</div>
                  <div style={{ background: 'var(--accent-muted)', border: '1px solid rgba(123,110,246,0.2)', borderRadius: '3px 10px 10px 10px', padding: '10px 13px', fontSize: 'var(--text-sm)', color: '#C4B5FD', lineHeight: 1.55, maxWidth: '88%' }}>
                    What does committing to that choice feel like — relief, or something closer to fear?
                  </div>
                </div>

                {/* Input bar */}
                <div style={{ marginTop: '14px', paddingTop: '12px', borderTop: '1px solid var(--border-ghost)' }}>
                  <div style={{ background: 'rgba(255,255,255,0.03)', border: '1px solid var(--border-hairline)', borderRadius: '8px', padding: '10px 14px', fontSize: 'var(--text-sm)', color: 'var(--text-faint)', fontStyle: 'italic' }}>
                    Share what's on your mind...
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </AnimatedReveal>
    </Container>
  </PageSection>
);
