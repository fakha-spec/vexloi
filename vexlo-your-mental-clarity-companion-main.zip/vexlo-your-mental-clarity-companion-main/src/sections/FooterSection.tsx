import { Container } from '../components/layout/Container';

export const FooterSection = () => (
  <footer style={{ background: 'var(--bg-footer)', borderTop: '1px solid var(--border-hairline)', padding: '36px 0' }}>
    <Container>
      <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: '12px' }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', width: '100%', flexWrap: 'wrap', gap: '12px' }}>
          <span style={{ fontFamily: 'var(--font-display)', fontSize: '21px', color: 'var(--text-primary)', letterSpacing: '-0.4px' }}>Vexlo</span>
          <span style={{ fontFamily: 'var(--font-body)', fontSize: 'var(--text-sm)', color: 'var(--text-faint)' }}>© 2025 Vexlo</span>
        </div>
        <div style={{ display: 'flex', gap: 'var(--space-6)', justifyContent: 'center', flexWrap: 'wrap' }}>
          {[
            { label: 'Privacy Policy', href: '#' },
            { label: 'Terms of Use', href: '#' },
            { label: 'hello@vexloai.com', href: 'mailto:hello@vexloai.com' },
          ].map((link) => (
            <a
              key={link.label}
              href={link.href}
              style={{ fontFamily: 'var(--font-body)', fontSize: 'var(--text-sm)', color: 'var(--text-faint)', textDecoration: 'none', transition: 'color var(--duration-fast) ease' }}
              onMouseEnter={(e) => { e.currentTarget.style.color = 'var(--text-secondary)'; }}
              onMouseLeave={(e) => { e.currentTarget.style.color = 'var(--text-faint)'; }}
            >
              {link.label}
            </a>
          ))}
        </div>
      </div>
    </Container>
  </footer>
);
