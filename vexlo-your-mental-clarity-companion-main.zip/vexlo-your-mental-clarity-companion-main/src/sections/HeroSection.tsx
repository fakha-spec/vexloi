import { Container } from '../components/layout/Container';
import { GlowBackground } from '../components/ui/GlowBackground';
import { SectionLabel } from '../components/ui/SectionLabel';
import { AnimatedReveal } from '../components/ui/AnimatedReveal';
import { WaitlistForm } from '../components/WaitlistForm';

export const HeroSection = () => (
  <section
    style={{
      position: 'relative',
      overflow: 'hidden',
      minHeight: '100vh',
      display: 'flex',
      alignItems: 'center',
      paddingTop: '140px',
      paddingBottom: '100px',
      backgroundColor: 'var(--bg-base)',
    }}
  >
    <GlowBackground intensity="strong" />
    <Container>
      <div style={{ position: 'relative', zIndex: 1, display: 'flex', flexDirection: 'column', alignItems: 'center', textAlign: 'center', width: '100%' }}>
        <AnimatedReveal>
          <SectionLabel text="Now accepting early access" />
        </AnimatedReveal>

        <AnimatedReveal delay={150}>
          <h1
            style={{
              fontFamily: 'var(--font-display)',
              fontSize: 'clamp(52px, 8vw, 92px)',
              color: 'var(--text-primary)',
              letterSpacing: '-0.04em',
              lineHeight: 1.04,
              maxWidth: '780px',
              margin: '0 auto',
              fontWeight: 300,
            }}
          >
            Your thoughts
            <br />
            deserve <em style={{ fontStyle: 'italic' }}>clarity.</em>
          </h1>
        </AnimatedReveal>

        <AnimatedReveal delay={300}>
          <p
            style={{
              fontFamily: 'var(--font-body)',
              fontSize: 'var(--text-md)',
              fontWeight: 300,
              color: 'var(--text-secondary)',
              lineHeight: 1.72,
              maxWidth: '500px',
              margin: 'var(--space-6) auto 0',
            }}
          >
            Vexlo is a private AI companion that helps you untangle what's weighing on your mind — without judgment, without noise, without anyone else knowing.
          </p>
        </AnimatedReveal>

        <AnimatedReveal delay={450}>
          <div style={{ marginTop: '36px', maxWidth: '520px', width: '100%' }}>
            <WaitlistForm layout="horizontal" />
          </div>
        </AnimatedReveal>
      </div>
    </Container>
  </section>
);
