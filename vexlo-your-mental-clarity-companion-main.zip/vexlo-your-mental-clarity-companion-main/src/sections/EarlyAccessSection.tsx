import { Container } from '../components/layout/Container';
import { GlowBackground } from '../components/ui/GlowBackground';
import { SectionLabel } from '../components/ui/SectionLabel';
import { AnimatedReveal } from '../components/ui/AnimatedReveal';
import { WaitlistForm } from '../components/WaitlistForm';

export const EarlyAccessSection = ({ id }: { id: string }) => (
  <section
    id={id}
    style={{
      position: 'relative',
      overflow: 'hidden',
      paddingTop: '120px',
      paddingBottom: '120px',
      backgroundColor: 'var(--bg-base)',
    }}
  >
    <GlowBackground intensity="strong" />
    <Container>
      <div style={{ position: 'relative', zIndex: 1, textAlign: 'center', display: 'flex', flexDirection: 'column', alignItems: 'center' }}>
        <AnimatedReveal><SectionLabel text="Limited early access" dot="success" /></AnimatedReveal>

        <AnimatedReveal delay={100}>
          <h2 style={{
            fontFamily: 'var(--font-display)',
            fontSize: 'clamp(38px, 5.5vw, 64px)',
            color: 'var(--text-primary)',
            letterSpacing: '-0.03em',
            lineHeight: 1.08,
            maxWidth: '600px',
            margin: '12px auto 0',
            fontWeight: 300,
          }}>
            Be the first to <em style={{ fontStyle: 'italic' }}>think clearly.</em>
          </h2>
        </AnimatedReveal>

        <AnimatedReveal delay={200}>
          <p style={{ fontFamily: 'var(--font-body)', fontSize: 'var(--text-md)', fontWeight: 300, color: 'var(--text-secondary)', lineHeight: 1.7, maxWidth: '480px', margin: '18px auto 0' }}>
            Vexlo is opening to a small, intentional group of early users. When your spot opens, you'll be the first to know.
          </p>
        </AnimatedReveal>

        <AnimatedReveal delay={300}>
          <div style={{ maxWidth: '420px', width: '100%', marginTop: '36px' }}>
            <WaitlistForm layout="stacked" />
          </div>
        </AnimatedReveal>
      </div>
    </Container>
  </section>
);
