import { Container } from '../components/layout/Container';
import { PageSection } from '../components/layout/PageSection';
import { SectionLabel } from '../components/ui/SectionLabel';
import { AnimatedReveal } from '../components/ui/AnimatedReveal';

const pillars = [
  {
    icon: (
      <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="var(--accent)" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
        <rect x="3" y="11" width="18" height="11" rx="2" ry="2" />
        <path d="M7 11V7a5 5 0 0 1 10 0v4" />
      </svg>
    ),
    title: 'End-to-end encrypted',
    body: 'Your conversations are encrypted in transit and at rest. We cannot read them.',
  },
  {
    icon: (
      <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="var(--accent)" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
        <path d="M17.94 17.94A10.07 10.07 0 0 1 12 20c-7 0-11-8-11-8a18.45 18.45 0 0 1 5.06-5.94M9.9 4.24A9.12 9.12 0 0 1 12 4c7 0 11 8 11 8a18.5 18.5 0 0 1-2.16 3.19m-6.72-1.07a3 3 0 1 1-4.24-4.24" />
        <line x1="1" y1="1" x2="23" y2="23" />
      </svg>
    ),
    title: 'Zero data selling',
    body: 'Your thoughts are not inventory. We will never sell, share, or monetize your data.',
  },
  {
    icon: (
      <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="var(--accent)" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
        <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4" />
        <polyline points="7 10 12 15 17 10" />
        <line x1="12" y1="15" x2="12" y2="3" />
      </svg>
    ),
    title: 'You own everything',
    body: 'Export or permanently delete your data at any time. No friction. No dark patterns.',
  },
  {
    icon: (
      <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="var(--accent)" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
        <path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2" />
        <circle cx="12" cy="7" r="4" />
        <polyline points="9 12 11 14 15 10" />
      </svg>
    ),
    title: 'Anonymous by default',
    body: 'Sign up with only an email. No real name, no phone, no social login ever required.',
  },
];

export const PrivacySection = () => (
  <PageSection bg="base">
    <Container>
      <div style={{ textAlign: 'center' }}>
        <AnimatedReveal><SectionLabel text="Your privacy" /></AnimatedReveal>
        <AnimatedReveal delay={100}>
          <h2 style={{
            fontFamily: 'var(--font-display)',
            fontSize: 'clamp(34px, 4.5vw, 56px)',
            color: 'var(--text-primary)',
            letterSpacing: '-0.03em',
            lineHeight: 1.10,
            fontWeight: 300,
            marginBottom: 'var(--space-4)',
          }}>
            Built to think, <em style={{ fontStyle: 'italic' }}>not to watch.</em>
          </h2>
        </AnimatedReveal>
        <AnimatedReveal delay={200}>
          <p style={{ fontFamily: 'var(--font-body)', fontSize: 'var(--text-md)', fontWeight: 300, color: 'var(--text-muted)', lineHeight: 1.65, maxWidth: '480px', margin: '0 auto var(--space-16)' }}>
            Privacy isn't a feature we added. It's the reason Vexlo exists.
          </p>
        </AnimatedReveal>
      </div>

      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(280px, 1fr))', gap: 'var(--space-4)', maxWidth: '760px', margin: '0 auto' }}>
        {pillars.map((p, i) => (
          <AnimatedReveal key={i} delay={200 + i * 80}>
            <div
              style={{
                background: 'var(--bg-surface)',
                border: '1px solid var(--border-hairline)',
                borderRadius: 'var(--radius-card)',
                padding: 'var(--space-6)',
                textAlign: 'left',
                boxShadow: 'var(--shadow-card)',
                transition: 'border-color var(--duration-base) var(--ease-in-out), box-shadow var(--duration-base) var(--ease-in-out)',
                cursor: 'default',
              }}
              onMouseEnter={(e) => {
                e.currentTarget.style.borderColor = 'var(--border-accent)';
                e.currentTarget.style.boxShadow = 'var(--shadow-card-hover)';
              }}
              onMouseLeave={(e) => {
                e.currentTarget.style.borderColor = 'var(--border-hairline)';
                e.currentTarget.style.boxShadow = 'var(--shadow-card)';
              }}
            >
              <div style={{ width: '32px', height: '32px', background: 'var(--accent-muted)', borderRadius: 'var(--radius-md)', display: 'flex', alignItems: 'center', justifyContent: 'center', marginBottom: 'var(--space-4)' }}>
                {p.icon}
              </div>
              <h3 style={{ fontFamily: 'var(--font-body)', fontSize: '16px', fontWeight: 600, color: 'var(--text-primary)', margin: '0 0 var(--space-2)' }}>{p.title}</h3>
              <p style={{ fontFamily: 'var(--font-body)', fontSize: '14px', fontWeight: 300, color: 'var(--text-muted)', lineHeight: 1.65, margin: 0 }}>{p.body}</p>
            </div>
          </AnimatedReveal>
        ))}
      </div>
    </Container>
  </PageSection>
);
