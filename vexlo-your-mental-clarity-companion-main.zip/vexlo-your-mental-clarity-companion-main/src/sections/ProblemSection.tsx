import { Container } from '../components/layout/Container';
import { PageSection } from '../components/layout/PageSection';
import { SectionLabel } from '../components/ui/SectionLabel';
import { AnimatedReveal } from '../components/ui/AnimatedReveal';

const cards = [
  {
    icon: (
      <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="var(--accent)" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
        <path d="M21 12a9 9 0 0 1-9 9m9-9a9 9 0 0 0-9-9m9 9H3m9 9a9 9 0 0 1-9-9m9 9c1.66 0 3-4.03 3-9s-1.34-9-3-9m0 18c-1.66 0-3-4.03-3-9s1.34-9 3-9M3 12a9 9 0 0 1 9-9" />
      </svg>
    ),
    title: 'The loop that never ends',
    body: 'You replay the same thought patterns. The more you think, the less you resolve.',
  },
  {
    icon: (
      <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="var(--accent)" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
        <path d="M12 22V2" />
        <path d="M5 19l7-7" />
        <path d="M19 19l-7-7" />
      </svg>
    ),
    title: 'Decisions that won\'t close',
    body: 'You know what matters. But every time you get close to deciding, another angle pulls you back.',
  },
  {
    icon: (
      <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="var(--accent)" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
        <path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z" />
        <rect x="10" y="8" width="4" height="6" rx="1" />
      </svg>
    ),
    title: 'No safe place to think',
    body: "Talking to people feels like a burden. You don't need advice. You need somewhere to think out loud.",
  },
];

export const ProblemSection = () => (
  <PageSection bg="surface" id="problem">
    <Container>
      <div style={{ textAlign: 'center' }}>
        <AnimatedReveal><SectionLabel text="The problem" /></AnimatedReveal>
        <AnimatedReveal delay={100}>
          <h2 style={{
            fontFamily: 'var(--font-display)',
            fontSize: 'clamp(34px, 4.5vw, 56px)',
            color: 'var(--text-primary)',
            letterSpacing: '-0.03em',
            lineHeight: 1.10,
            maxWidth: '560px',
            margin: '0 auto var(--space-16)',
            fontWeight: 300,
          }}>
            The noise never stops.
          </h2>
        </AnimatedReveal>
      </div>

      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(260px, 1fr))', gap: 'var(--space-5)' }}>
        {cards.map((card, i) => (
          <AnimatedReveal key={i} delay={200 + i * 80}>
            <div
              style={{
                background: 'var(--bg-raised)',
                border: '1px solid var(--border-hairline)',
                borderRadius: 'var(--radius-card)',
                padding: 'var(--space-6) var(--space-8)',
                textAlign: 'left',
                transition: 'border-color var(--duration-base) var(--ease-in-out), box-shadow var(--duration-base) var(--ease-in-out)',
                cursor: 'default',
                boxShadow: 'var(--shadow-card)',
              }}
              onMouseEnter={(e) => {
                e.currentTarget.style.borderColor = 'var(--border-accent)';
                e.currentTarget.style.boxShadow = 'var(--shadow-card-hover)';
              }}
              onMouseLeave={(e) => {
                e.currentTarget.style.borderColor = 'var(--border-hairline)';
                e.currentTarget.style.boxShadow = 'var(--shadow-card)';
              }}
            >
              <div style={{ width: '36px', height: '36px', background: 'var(--accent-muted)', borderRadius: 'var(--radius-md)', display: 'flex', alignItems: 'center', justifyContent: 'center', marginBottom: 'var(--space-5)' }}>
                {card.icon}
              </div>
              <h3 style={{ fontFamily: 'var(--font-body)', fontSize: '16px', fontWeight: 600, color: 'var(--text-primary)', margin: '0 0 var(--space-2)' }}>{card.title}</h3>
              <p style={{ fontFamily: 'var(--font-body)', fontSize: '14px', fontWeight: 300, color: 'var(--text-muted)', lineHeight: 1.65, margin: 0 }}>{card.body}</p>
            </div>
          </AnimatedReveal>
        ))}
      </div>
    </Container>
  </PageSection>
);
