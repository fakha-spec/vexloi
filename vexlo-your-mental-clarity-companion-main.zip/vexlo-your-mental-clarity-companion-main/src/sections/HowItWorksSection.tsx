import { Container } from '../components/layout/Container';
import { PageSection } from '../components/layout/PageSection';
import { SectionLabel } from '../components/ui/SectionLabel';
import { AnimatedReveal } from '../components/ui/AnimatedReveal';

const steps = [
  {
    num: '01',
    icon: (
      <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="var(--accent)" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
        <path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z" />
        <circle cx="9" cy="10" r="1" fill="var(--accent)" />
        <circle cx="12" cy="10" r="1" fill="var(--accent)" />
        <circle cx="15" cy="10" r="1" fill="var(--accent)" />
      </svg>
    ),
    title: 'Tell Vexlo what\'s on your mind',
    body: 'No structure required. No right way to start. Just say what\'s there.',
  },
  {
    num: '02',
    icon: (
      <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="var(--accent)" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
        <circle cx="12" cy="12" r="10" />
        <path d="M9.09 9a3 3 0 0 1 5.83 1c0 2-3 3-3 3" />
        <circle cx="12" cy="17" r="0.5" fill="var(--accent)" />
      </svg>
    ),
    title: 'Let the questions work',
    body: 'Vexlo asks precise questions that move you from circling to understanding.',
  },
  {
    num: '03',
    icon: (
      <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="var(--accent)" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
        <polygon points="13 2 3 14 12 14 11 22 21 10 12 10 13 2" />
      </svg>
    ),
    title: 'Leave with a clear next step',
    body: 'Every conversation ends with a perspective that\'s genuinely your own.',
  },
];

export const HowItWorksSection = () => (
  <PageSection bg="surface">
    <Container>
      <div style={{ textAlign: 'center' }}>
        <AnimatedReveal><SectionLabel text="The process" /></AnimatedReveal>
        <AnimatedReveal delay={100}>
          <h2 style={{
            fontFamily: 'var(--font-display)',
            fontSize: 'clamp(34px, 4.5vw, 56px)',
            color: 'var(--text-primary)',
            letterSpacing: '-0.03em',
            lineHeight: 1.10,
            fontWeight: 300,
            marginBottom: 'var(--space-16)',
          }}>
            Three steps to a clearer mind.
          </h2>
        </AnimatedReveal>
      </div>

      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(240px, 1fr))', gap: 'var(--space-5)', maxWidth: '800px', margin: '0 auto' }}>
        {steps.map((step, i) => (
          <AnimatedReveal key={i} delay={150 + i * 80}>
            <div style={{ textAlign: 'center', padding: '0 var(--space-6)', position: 'relative' }}>
              <span style={{
                fontFamily: 'var(--font-display)',
                fontSize: '40px',
                fontWeight: 300,
                fontStyle: 'italic',
                color: 'rgba(123,110,246,0.18)',
                lineHeight: 1,
                display: 'block',
                marginBottom: 'var(--space-3)',
                letterSpacing: '-1px',
              }}>
                {step.num}
              </span>
              {/* Divider line */}
              <div style={{ width: '24px', height: '1px', background: 'var(--border-accent)', margin: '0 auto var(--space-4)' }} />
              <div style={{ width: '48px', height: '48px', background: 'var(--bg-raised)', border: '1px solid var(--border-subtle)', borderRadius: '50%', display: 'flex', alignItems: 'center', justifyContent: 'center', margin: '0 auto var(--space-5)' }}>
                {step.icon}
              </div>
              <h3 style={{ fontFamily: 'var(--font-body)', fontSize: '16px', fontWeight: 600, color: 'var(--text-primary)', marginBottom: 'var(--space-2)' }}>{step.title}</h3>
              <p style={{ fontFamily: 'var(--font-body)', fontSize: '14px', fontWeight: 300, color: 'var(--text-muted)', lineHeight: 1.65, maxWidth: '220px', margin: '0 auto' }}>{step.body}</p>
            </div>
          </AnimatedReveal>
        ))}
      </div>
    </Container>
  </PageSection>
);
