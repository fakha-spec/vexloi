export const SectionLabel = ({ text, dot }: { text: string; dot?: 'success' }) => (
  <div style={{ textAlign: 'center', marginBottom: 'var(--space-5)' }}>
    <span
      style={{
        color: 'var(--text-tertiary)',
        fontFamily: 'var(--font-body)',
        fontSize: 'var(--text-xs)',
        fontWeight: 600,
        letterSpacing: '0.08em',
        textTransform: 'uppercase' as const,
        display: 'inline-flex',
        alignItems: 'center',
        gap: '8px',
      }}
    >
      {dot === 'success' && (
        <span
          className="badge-live"
          style={{
            width: '6px',
            height: '6px',
            borderRadius: '50%',
            background: 'var(--success)',
            display: 'inline-block',
            animation: 'pulse-dot 2.5s ease-in-out infinite',
          }}
        />
      )}
      {text}
    </span>
  </div>
);
