export const GlowBackground = ({ intensity = 'soft' }: { intensity?: 'soft' | 'strong' }) => {
  const opacity = intensity === 'strong' ? 0.14 : 0.08;
  const midOpacity = intensity === 'strong' ? 0.04 : 0.02;
  return (
    <div
      style={{
        position: 'absolute',
        inset: 0,
        pointerEvents: 'none',
        zIndex: 0,
        overflow: 'hidden',
      }}
    >
      <div
        style={{
          position: 'absolute',
          inset: 0,
          background: `radial-gradient(ellipse 55% 45% at 50% 38%, rgba(123,110,246,${opacity}) 0%, rgba(123,110,246,${midOpacity}) 45%, transparent 70%)`,
        }}
      />
      <div
        className="noise-layer"
        style={{
          position: 'absolute',
          inset: 0,
          backgroundImage: `url("data:image/svg+xml,%3Csvg viewBox='0 0 256 256' xmlns='http://www.w3.org/2000/svg'%3E%3Cfilter id='n'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='0.9' numOctaves='4' stitchTiles='stitch'/%3E%3C/filter%3E%3Crect width='100%25' height='100%25' filter='url(%23n)' opacity='1'/%3E%3C/svg%3E")`,
          backgroundSize: '220px 220px',
          opacity: 0.025,
          animation: 'none',
        }}
      />
      <style>{`
        @media (hover: hover) {
          .noise-layer { animation: noise-drift 12s linear infinite !important; }
        }
      `}</style>
    </div>
  );
};
