import { useState, FormEvent } from 'react';

type Status = 'idle' | 'loading' | 'success' | 'error';

export const WaitlistForm = ({ layout }: { layout: 'horizontal' | 'stacked' }) => {
  const [email, setEmail] = useState('');
  const [status, setStatus] = useState<Status>('idle');
  const [errorMessage, setErrorMessage] = useState('');

  const handleSubmit = async (e: FormEvent) => {
    e.preventDefault();
    const trimmed = email.trim();
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(trimmed)) {
      setStatus('error');
      setErrorMessage('Please enter a valid email address.');
      return;
    }
    setStatus('loading');
    try {
      const res = await fetch(
        `${import.meta.env.VITE_SUPABASE_URL}/functions/v1/join-waitlist`,
        {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            apikey: import.meta.env.VITE_SUPABASE_PUBLISHABLE_KEY,
          },
          body: JSON.stringify({ email: trimmed.toLowerCase() }),
          signal: AbortSignal.timeout(10000),
        }
      );
      const data = await res.json();
      if (res.ok && data.success && !data.already_exists) {
        setStatus('success');
      } else if (res.ok && data.already_exists) {
        setStatus('error');
        setErrorMessage("You're already on the list — we'll be in touch.");
      } else if (res.status === 400) {
        setStatus('error');
        setErrorMessage('Please enter a valid email address.');
      } else {
        setStatus('error');
        setErrorMessage('Something went wrong. Please try again in a moment.');
      }
    } catch {
      setStatus('error');
      setErrorMessage('Something went wrong. Please try again in a moment.');
    }
  };

  const isHorizontal = layout === 'horizontal';

  const trustCopy = (
    <div style={{ marginTop: 'var(--space-3)', textAlign: 'center' }}>
      <p style={{ fontFamily: 'var(--font-body)', fontSize: 'var(--text-sm)', color: 'var(--text-tertiary)', margin: 0, fontWeight: 400 }}>
        No card required. We won't email you more than once until you're in.
      </p>
      <div style={{ display: 'flex', alignItems: 'center', gap: '0', marginTop: '8px', justifyContent: 'center' }}>
        <div style={{ display: 'flex' }}>
          {[0, 1, 2].map((i) => (
            <div
              key={i}
              style={{
                width: '24px',
                height: '24px',
                borderRadius: '50%',
                background: 'linear-gradient(135deg, #4B44B8, #7B6EF6)',
                border: '2px solid var(--bg-base)',
                marginRight: i < 2 ? '-7px' : '0',
                display: 'inline-block',
              }}
            />
          ))}
        </div>
        <span style={{ fontFamily: 'var(--font-body)', fontSize: 'var(--text-xs)', color: 'var(--text-muted)', marginLeft: '16px' }}>
          2,400+ people already waiting
        </span>
      </div>
    </div>
  );

  if (status === 'success') {
    return (
      <div>
        <div
          style={{
            background: 'var(--success-bg)',
            border: '1px solid var(--success-border)',
            borderRadius: '12px',
            padding: '18px 22px',
          }}
        >
          <div style={{ display: 'flex', alignItems: 'center', gap: '10px' }}>
            <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="#22C55E" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
              <polyline points="20 6 9 17 4 12" />
            </svg>
            <span style={{ fontFamily: 'var(--font-body)', fontSize: 'var(--text-base)', fontWeight: 600, color: 'var(--success-text)' }}>
              You're on the list.
            </span>
          </div>
          <p style={{ fontFamily: 'var(--font-body)', fontSize: 'var(--text-sm)', color: '#4ADE80', margin: '8px 0 0' }}>
            Share with someone who needs clarity → vexloai.com
          </p>
        </div>
        {trustCopy}
      </div>
    );
  }

  return (
    <div>
      <form
        onSubmit={handleSubmit}
        style={{
          display: 'flex',
          flexDirection: isHorizontal ? 'row' : 'column',
          gap: 'var(--space-3)',
          alignItems: isHorizontal ? 'stretch' : undefined,
        }}
      >
        <input
          type="email"
          value={email}
          onChange={(e) => { setEmail(e.target.value); if (status === 'error') setStatus('idle'); }}
          placeholder="Enter your email"
          aria-label="Email address"
          disabled={status === 'loading'}
          style={{
            flex: isHorizontal ? '1' : undefined,
            width: isHorizontal ? undefined : '100%',
            background: 'var(--bg-raised)',
            border: '1px solid var(--border-subtle)',
            color: 'var(--text-primary)',
            borderRadius: 'var(--radius-input)',
            padding: '12px 16px',
            fontFamily: 'var(--font-body)',
            fontSize: 'var(--text-base)',
            outline: 'none',
            minHeight: '44px',
          }}
          onFocus={(e) => {
            e.currentTarget.style.borderColor = 'var(--accent)';
            e.currentTarget.style.boxShadow = '0 0 0 3px rgba(123,110,246,0.16)';
          }}
          onBlur={(e) => {
            e.currentTarget.style.borderColor = 'var(--border-subtle)';
            e.currentTarget.style.boxShadow = 'none';
          }}
        />
        <button
          type="submit"
          disabled={status === 'loading'}
          style={{
            background: 'var(--accent)',
            color: 'white',
            border: '1px solid rgba(255,255,255,0.08)',
            borderRadius: 'var(--radius-button)',
            padding: '11px 22px',
            fontFamily: 'var(--font-body)',
            fontSize: 'var(--text-base)',
            fontWeight: 500,
            whiteSpace: 'nowrap' as const,
            cursor: status === 'loading' ? 'wait' : 'pointer',
            transition: 'background var(--duration-fast) ease, box-shadow var(--duration-base) ease',
            width: isHorizontal ? undefined : '100%',
            flexShrink: 0,
            minHeight: '44px',
          }}
          onMouseEnter={(e) => {
            e.currentTarget.style.background = 'var(--accent-hover)';
            e.currentTarget.style.boxShadow = '0 0 20px rgba(123,110,246,0.25)';
          }}
          onMouseLeave={(e) => {
            e.currentTarget.style.background = 'var(--accent)';
            e.currentTarget.style.boxShadow = 'none';
          }}
        >
          {status === 'loading' ? (
            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="white" strokeWidth="2" strokeLinecap="round" aria-hidden="true" style={{ animation: 'spin 0.7s linear infinite' }}>
              <path d="M21 12a9 9 0 1 1-6.219-8.56" />
            </svg>
          ) : (
            'Get Early Access'
          )}
        </button>
      </form>
      {status === 'error' && (
        <p style={{ fontFamily: 'var(--font-body)', fontSize: 'var(--text-sm)', color: 'var(--error-text)', marginTop: 'var(--space-2)' }}>
          {errorMessage}
        </p>
      )}
      {trustCopy}
    </div>
  );
};
