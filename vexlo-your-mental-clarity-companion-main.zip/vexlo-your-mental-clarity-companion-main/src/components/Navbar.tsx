import { useState, useEffect } from 'react';
import { Container } from './layout/Container';

export const Navbar = () => {
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const handler = () => setScrolled(window.scrollY > 10);
    window.addEventListener('scroll', handler, { passive: true });
    return () => window.removeEventListener('scroll', handler);
  }, []);

  return (
    <nav
      style={{
        position: 'fixed',
        top: 0,
        left: 0,
        right: 0,
        zIndex: 50,
        height: '64px',
        background: scrolled ? 'rgba(10,10,16,0.88)' : 'transparent',
        backdropFilter: scrolled ? 'blur(16px) saturate(160%)' : 'none',
        WebkitBackdropFilter: scrolled ? 'blur(16px) saturate(160%)' : 'none',
        borderBottom: scrolled ? '1px solid var(--border-hairline)' : '1px solid transparent',
        transition: 'background 300ms ease-in-out, backdrop-filter 300ms ease-in-out, border-bottom 300ms ease-in-out',
      }}
    >
      <Container>
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', height: '64px' }}>
          <span
            style={{
              fontFamily: 'var(--font-display)',
              fontSize: '21px',
              color: 'var(--text-primary)',
              letterSpacing: '-0.4px',
              cursor: 'pointer',
            }}
          >
            Vexlo
          </span>
          <button
            onClick={() => document.getElementById('early-access')?.scrollIntoView({ behavior: 'smooth' })}
            style={{
              background: 'transparent',
              border: '1px solid var(--border-subtle)',
              color: 'var(--text-secondary)',
              borderRadius: 'var(--radius-button)',
              padding: '8px 18px',
              fontFamily: 'var(--font-body)',
              fontSize: '14px',
              fontWeight: 500,
              cursor: 'pointer',
              transition: 'all var(--duration-fast) ease',
              minHeight: '44px',
            }}
            onMouseEnter={(e) => {
              e.currentTarget.style.borderColor = 'var(--border-visible)';
              e.currentTarget.style.color = 'var(--text-primary)';
            }}
            onMouseLeave={(e) => {
              e.currentTarget.style.borderColor = 'var(--border-subtle)';
              e.currentTarget.style.color = 'var(--text-secondary)';
            }}
          >
            Request Access
          </button>
        </div>
      </Container>
    </nav>
  );
};
