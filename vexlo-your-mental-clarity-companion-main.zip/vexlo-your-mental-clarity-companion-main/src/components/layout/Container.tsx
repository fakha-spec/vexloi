import { ReactNode } from 'react';

export const Container = ({ children, className = '' }: { children: ReactNode; className?: string }) => (
  <div
    className={className}
    style={{
      maxWidth: 'var(--container-max)',
      marginLeft: 'auto',
      marginRight: 'auto',
      paddingLeft: 'clamp(16px, 4vw, 24px)',
      paddingRight: 'clamp(16px, 4vw, 24px)',
    }}
  >
    {children}
  </div>
);
