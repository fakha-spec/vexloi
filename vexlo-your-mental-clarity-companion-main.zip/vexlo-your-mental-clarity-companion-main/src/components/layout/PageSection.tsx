import { ReactNode } from 'react';

const bgMap = {
  base: 'var(--bg-base)',
  surface: 'var(--bg-surface)',
  raised: 'var(--bg-raised)',
};

export const PageSection = ({
  children,
  className = '',
  id,
  bg = 'base',
}: {
  children: ReactNode;
  className?: string;
  id?: string;
  bg?: 'base' | 'surface' | 'raised';
}) => (
  <section
    id={id}
    className={className}
    style={{
      backgroundColor: bgMap[bg],
      paddingTop: 'var(--section-padding-y)',
      paddingBottom: 'var(--section-padding-y)',
    }}
  >
    {children}
  </section>
);
