import { Navbar } from './components/Navbar';
import { HeroSection } from './sections/HeroSection';
import { ProblemSection } from './sections/ProblemSection';
import { SolutionSection } from './sections/SolutionSection';
import { HowItWorksSection } from './sections/HowItWorksSection';
import { PrivacySection } from './sections/PrivacySection';
import { EarlyAccessSection } from './sections/EarlyAccessSection';
import { FooterSection } from './sections/FooterSection';
import './global.css';

const App = () => (
  <>
    <Navbar />
    <HeroSection />
    <ProblemSection />
    <SolutionSection />
    <HowItWorksSection />
    <PrivacySection />
    <EarlyAccessSection id="early-access" />
    <FooterSection />
  </>
);

export default App;
